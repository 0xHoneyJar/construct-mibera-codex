import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-card{background:var(--surface-panel);border:1px solid var(--rule-medium);border-radius:0;color:var(--text-body)}
.mib-card.hoverable{transition:border-color var(--duration-fast) var(--ease-out-expo)}
.mib-card.hoverable:hover{border-color:var(--text-body)}
.mib-card-head{padding:14px 18px 0;display:flex;flex-direction:column;gap:6px}
.mib-card-kicker{font-family:var(--font-mono);font-size:9px;letter-spacing:var(--tracking-kicker);text-transform:uppercase;color:var(--text-muted)}
.mib-card-title{font-family:var(--font-display);font-size:20px;line-height:1.15}
.mib-card-rule{border-top:1px solid var(--rule-soft);margin:12px 0 0}
.mib-card-body{padding:14px 18px;font-size:13.5px;line-height:1.55;color:var(--text-secondary)}
.mib-card-foot{padding:12px 18px;border-top:1px solid var(--rule-soft);display:flex;align-items:center;gap:10px;font-family:var(--font-mono);font-size:10px;letter-spacing:0.06em;color:var(--text-muted)}`;
export function Card({kicker,title,footer,hoverable=false,children,style}){
  ensureMibStyle('mib-card-css',css);
  return <div className={`mib-card${hoverable?' hoverable':''}`} style={style}>
    {(kicker||title) && <div className="mib-card-head">{kicker&&<span className="mib-card-kicker">{kicker}</span>}{title&&<span className="mib-card-title">{title}</span>}<div className="mib-card-rule"></div></div>}
    <div className="mib-card-body">{children}</div>
    {footer && <div className="mib-card-foot">{footer}</div>}
  </div>;
}

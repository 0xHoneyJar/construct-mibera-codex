Inverse-panel notification with a 2px accent top edge; position it yourself (fixed stack, bottom-left).

```jsx
<Toast title="Minted" message="Mibera #0042 joined the rave." />
```

export interface ToastProps {
  /** Mono-caps headline. */
  title?: string;
  message?: string;
  /** accent (default) or danger — colors the 2px top edge. */
  tone?: 'accent' | 'danger';
  style?: React.CSSProperties;
}

export interface TooltipProps {
  label: React.ReactNode;
  position?: 'top' | 'bottom';
  /** The trigger element. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

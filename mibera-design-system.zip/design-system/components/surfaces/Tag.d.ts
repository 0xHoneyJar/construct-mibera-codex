export interface TagProps {
  /** Shows a ✕ remove affordance when provided. */
  onRemove?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

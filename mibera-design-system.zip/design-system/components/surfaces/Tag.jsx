import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-tag{display:inline-flex;align-items:center;gap:8px;font-family:var(--font-mono);font-size:10.5px;letter-spacing:0.05em;padding:4px 10px;border:1px solid var(--border-default);color:var(--text-body);background:var(--surface-panel);border-radius:0}
.mib-tag button{all:unset;cursor:pointer;font-size:11px;color:var(--text-muted);line-height:1}
.mib-tag button:hover{color:var(--danger)}
.mib-tag button:focus-visible{outline:2px solid var(--focus-ring);outline-offset:1px}`;
export function Tag({onRemove,children,style}){
  ensureMibStyle('mib-tag-css',css);
  return <span className="mib-tag" style={style}>{children}{onRemove&&<button aria-label="Remove" onClick={onRemove}>✕</button>}</span>;
}

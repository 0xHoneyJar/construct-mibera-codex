export interface CardProps {
  /** Wide-tracked mono micro label above the title. */
  kicker?: string;
  title?: React.ReactNode;
  /** Mono footer row under a hairline. */
  footer?: React.ReactNode;
  /** Border darkens to full text color on hover. */
  hoverable?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-tip-wrap{position:relative;display:inline-flex}
.mib-tip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%) translateY(2px);background:var(--surface-inverse);color:var(--text-inverse);font-family:var(--font-mono);font-size:10px;letter-spacing:0.06em;padding:5px 9px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity var(--duration-fast) var(--ease-out-expo),transform var(--duration-fast) var(--ease-out-expo);z-index:50}
.mib-tip-wrap:hover .mib-tip,.mib-tip-wrap:focus-within .mib-tip{opacity:1;transform:translateX(-50%) translateY(0)}
.mib-tip.bottom{bottom:auto;top:calc(100% + 8px)}`;
export function Tooltip({label,position='top',children,style}){
  ensureMibStyle('mib-tip-css',css);
  return <span className="mib-tip-wrap" style={style}>{children}<span className={`mib-tip${position==='bottom'?' bottom':''}`} role="tooltip">{label}</span></span>;
}

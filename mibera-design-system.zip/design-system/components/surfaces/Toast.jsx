import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-toast{display:flex;flex-direction:column;gap:3px;min-width:260px;max-width:380px;background:var(--surface-inverse);color:var(--text-inverse);padding:12px 16px;border-top:2px solid var(--accent);animation:mibToastIn var(--duration-normal) var(--spring-snappy)}
.mib-toast-title{font-family:var(--font-mono);font-size:10.5px;font-weight:500;letter-spacing:var(--tracking-caps);text-transform:uppercase}
.mib-toast-msg{font-family:var(--font-body);font-size:13px;line-height:1.5;opacity:0.85}
.mib-toast-danger{border-top-color:var(--danger)}
@keyframes mibToastIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`;
export function Toast({title,message,tone='accent',style}){
  ensureMibStyle('mib-toast-css',css);
  return <div className={`mib-toast${tone==='danger'?' mib-toast-danger':''}`} role="status" style={style}>
    {title && <span className="mib-toast-title">{title}</span>}
    {message && <span className="mib-toast-msg">{message}</span>}
  </div>;
}

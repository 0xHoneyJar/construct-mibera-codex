Modal with 2px heavy border and ink scrim; scrim-click and ✕ both close.

```jsx
<Dialog open={open} onClose={close} title="Burn Milady?" footer={<Button variant="danger">Burn</Button>}>
  Sometimes refusal is combustion.
</Dialog>
```

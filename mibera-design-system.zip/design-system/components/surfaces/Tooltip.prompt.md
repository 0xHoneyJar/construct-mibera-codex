Inverse mono micro-tooltip on hover/focus.

```jsx
<Tooltip label="SS1 · Ultra Rare"><Badge>SS1</Badge></Tooltip>
```

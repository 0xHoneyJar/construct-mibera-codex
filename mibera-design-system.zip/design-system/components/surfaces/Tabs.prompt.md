Underline tab strip; active tab carries a 2px accent underline.

```jsx
<Tabs items={['By Archetype','By Drug','By Era']} onChange={setFacet}/>
```

export interface BadgeProps {
  variant?: 'neutral' | 'accent' | 'inverse' | 'danger';
  /** Capsule corners — the only pill license in the system. */
  pill?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

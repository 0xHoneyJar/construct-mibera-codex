Removable filter token for trait/facet filtering.

```jsx
<Tag onRemove={()=>drop('freetekno')}>archetype: freetekno</Tag>
```

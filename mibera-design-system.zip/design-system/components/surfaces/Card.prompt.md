Flat panel card: kicker → display title → hairline → body. No shadow, no radius.

```jsx
<Card kicker="V. THE COLLECTION" title="The Grails" footer="44 hand-drawn 1/1s" hoverable>
  42 canonical + 2 community pieces.
</Card>
```

export interface TabsProps {
  /** Strings or {id,label} pairs. */
  items: Array<string | { id: string; label: React.ReactNode }>;
  /** Controlled active id. */
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
  style?: React.CSSProperties;
}

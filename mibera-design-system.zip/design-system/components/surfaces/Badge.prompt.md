Mono-caps status chip; use for swag tiers (SS1–SS5), ranks, statuses.

```jsx
<Badge variant="accent">SS1 · Ultra Rare</Badge>
```

import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-tabs{display:flex;gap:2px;border-bottom:1px solid var(--rule-medium)}
.mib-tab{all:unset;cursor:pointer;font-family:var(--font-mono);font-size:11px;letter-spacing:var(--tracking-caps);text-transform:uppercase;padding:10px 16px;color:var(--text-muted);border-bottom:2px solid transparent;margin-bottom:-1px;transition:color var(--duration-fast) var(--ease-out-expo)}
.mib-tab:hover{color:var(--text-body)}
.mib-tab:focus-visible{outline:2px solid var(--focus-ring);outline-offset:-2px}
.mib-tab.active{color:var(--text-body);border-bottom-color:var(--accent)}`;
export function Tabs({items=[],value,defaultValue,onChange,style}){
  ensureMibStyle('mib-tabs-css',css);
  const [internal,setInternal]=React.useState(defaultValue??(items[0]&&(items[0].id??items[0])));
  const active=value??internal;
  const pick=id=>{setInternal(id);onChange&&onChange(id);};
  return <div className="mib-tabs" role="tablist" style={style}>
    {items.map(it=>{const id=it.id??it,label=it.label??it;
      return <button key={id} role="tab" aria-selected={active===id} className={`mib-tab${active===id?' active':''}`} onClick={()=>pick(id)}>{label}</button>;})}
  </div>;
}

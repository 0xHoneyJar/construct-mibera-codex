import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-badge{display:inline-flex;align-items:center;gap:6px;font-family:var(--font-mono);font-size:9.5px;font-weight:500;letter-spacing:var(--tracking-caps);text-transform:uppercase;padding:3px 9px;border-radius:0;line-height:1.5}
.mib-badge-neutral{color:var(--text-secondary);border:1px solid var(--border-default)}
.mib-badge-accent{background:var(--accent);color:var(--on-accent);border:1px solid var(--accent)}
.mib-badge-inverse{background:var(--surface-inverse);color:var(--text-inverse);border:1px solid var(--surface-inverse)}
.mib-badge-danger{color:var(--danger);border:1px solid var(--danger)}
.mib-badge-pill{border-radius:var(--radius-full);padding:3px 11px}`;
export function Badge({variant='neutral',pill=false,children,style}){
  ensureMibStyle('mib-badge-css',css);
  return <span className={`mib-badge mib-badge-${variant}${pill?' mib-badge-pill':''}`} style={style}>{children}</span>;
}

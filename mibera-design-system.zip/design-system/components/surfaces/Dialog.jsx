import {ensureMibStyle} from '../forms/Button.jsx';
const css=`
.mib-dialog-scrim{position:fixed;inset:0;background:color-mix(in oklch,var(--surface-inverse) 45%,transparent);display:flex;align-items:center;justify-content:center;z-index:100;animation:mibFade var(--duration-normal) var(--ease-out-expo)}
.mib-dialog{background:var(--surface-page);color:var(--text-body);border:2px solid var(--text-body);width:min(480px,90vw);max-height:85vh;overflow:auto;animation:mibRise var(--duration-normal) var(--ease-out-expo)}
.mib-dialog-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:20px 24px 0}
.mib-dialog-title{font-family:var(--font-display);font-size:24px;line-height:1.1}
.mib-dialog-x{all:unset;cursor:pointer;font-family:var(--font-mono);font-size:14px;color:var(--text-muted);padding:2px 6px}
.mib-dialog-x:hover{color:var(--text-body)}
.mib-dialog-x:focus-visible{outline:2px solid var(--focus-ring)}
.mib-dialog-body{padding:14px 24px 20px;font-size:14px;line-height:1.6;color:var(--text-secondary)}
.mib-dialog-foot{padding:16px 24px;border-top:1px solid var(--rule-soft);display:flex;justify-content:flex-end;gap:10px}
@keyframes mibFade{from{opacity:0}to{opacity:1}}
@keyframes mibRise{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}`;
export function Dialog({open=false,onClose,title,footer,children,style}){
  ensureMibStyle('mib-dialog-css',css);
  if(!open) return null;
  return <div className="mib-dialog-scrim" onClick={e=>{if(e.target===e.currentTarget&&onClose)onClose();}}>
    <div className="mib-dialog" role="dialog" aria-modal="true" style={style}>
      <div className="mib-dialog-head"><div className="mib-dialog-title">{title}</div><button className="mib-dialog-x" aria-label="Close" onClick={onClose}>✕</button></div>
      <div className="mib-dialog-body">{children}</div>
      {footer && <div className="mib-dialog-foot">{footer}</div>}
    </div>
  </div>;
}

import {ensureMibStyle} from './Button.jsx';
/* Verbatim from mibera-dimensions lib/themes.ts — used by the app's theme selectors and preview cards. */
export const MIBERA_THEMES=[
 {id:"nier-default",name:"Default",color:"#1a1612",bg:"#d4c8b8",text:"#1a1612"},
 {id:"acid-house",name:"Acid House",color:"#c94b9a",bg:"#110e10",text:"#e6ddd0"},
 {id:"freetekno",name:"Freetekno",color:"#45a872",bg:"#0e1310",text:"#dce4dc"},
 {id:"chicago-detroit-nyc",name:"Chicago",color:"#9e3a30",bg:"#d4dde8",text:"#141c30"},
 {id:"milady",name:"Milady",color:"#1d2783",bg:"#e2e2e2",text:"#18161a"}
];
const css=`
.mib-themesw{display:inline-flex;border:1px solid var(--border-default);background:var(--surface-panel)}
.mib-themesw button{all:unset;display:inline-flex;align-items:center;gap:8px;height:34px;padding:0 13px;cursor:pointer;font-family:var(--font-mono);font-size:10px;font-weight:500;letter-spacing:var(--tracking-caps);text-transform:uppercase;color:var(--text-secondary);border-right:1px solid var(--border-default);transition:background-color var(--duration-fast) var(--ease-out-expo),color var(--duration-fast) var(--ease-out-expo)}
.mib-themesw button:last-child{border-right:none}
.mib-themesw button:hover{color:var(--text-body);background:var(--surface-panel-2)}
.mib-themesw button:focus-visible{outline:2px solid var(--focus-ring);outline-offset:-2px}
.mib-themesw button.active{background:var(--accent);color:var(--on-accent)}
.mib-themesw .chip{width:12px;height:12px;border:1px solid rgba(0,0,0,0.25);position:relative;flex:none}
.mib-themesw .chip i{position:absolute;inset:3px}`;
export function ThemeSwitcher({value,defaultValue='nier-default',onChange,applyTo='document',style}){
  ensureMibStyle('mib-themesw-css',css);
  const [internal,setInternal]=React.useState(defaultValue);
  const active=value??internal;
  React.useEffect(()=>{
    if(applyTo!=='document')return;
    /* next-themes disableTransitionOnChange pattern (mibera-dimensions wraps next-themes):
       suppress ALL transitions for one frame while the theme applies, else Chromium keeps
       stale transitioned colors when var() endpoints change via inherited custom props. */
    const s=document.createElement('style');
    s.textContent='*,*::before,*::after{transition:none!important}';
    document.head.appendChild(s);
    document.documentElement.setAttribute('data-theme',active);
    void document.documentElement.offsetWidth;
    requestAnimationFrame(()=>s.remove());
  },[active,applyTo]);
  const pick=id=>{setInternal(id);onChange&&onChange(id);};
  return <div className="mib-themesw" role="radiogroup" aria-label="Theme" style={style}>
    {MIBERA_THEMES.map(t=><button key={t.id} role="radio" aria-checked={active===t.id} className={active===t.id?'active':''} onClick={()=>pick(t.id)}>
      <span className="chip" style={{background:t.bg}}><i style={{background:t.color}}></i></span>{t.name}
    </button>)}
  </div>;
}

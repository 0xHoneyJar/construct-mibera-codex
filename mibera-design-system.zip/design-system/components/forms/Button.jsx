const css=`
.mib-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:var(--font-mono);font-weight:500;text-transform:uppercase;letter-spacing:var(--tracking-caps);border-radius:0;cursor:pointer;user-select:none;transition:background-color var(--duration-fast) var(--ease-out-expo),color var(--duration-fast) var(--ease-out-expo),border-color var(--duration-fast) var(--ease-out-expo)}
.mib-btn:active:not(:disabled){transform:translateY(1px)}
.mib-btn:focus-visible{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-btn:disabled{opacity:0.4;cursor:not-allowed}
.mib-btn-primary{background:var(--accent);color:var(--on-accent);border:1px solid var(--accent)}
.mib-btn-primary:hover:not(:disabled){background:color-mix(in oklch,var(--accent) 82%,var(--surface-page))}
.mib-btn-secondary{background:transparent;color:var(--text-body);border:1px solid var(--border-default)}
.mib-btn-secondary:hover:not(:disabled){border-color:var(--text-body);background:var(--surface-panel)}
.mib-btn-ghost{background:transparent;color:var(--text-secondary);border:1px solid transparent}
.mib-btn-ghost:hover:not(:disabled){color:var(--text-body);background:var(--surface-panel)}
.mib-btn-danger{background:var(--danger);color:#FFF6F4;border:1px solid var(--danger)}
.mib-btn-danger:hover:not(:disabled){background:color-mix(in oklch,var(--danger) 82%,var(--surface-page))}
.mib-btn-sm{height:28px;padding:0 12px;font-size:10px}
.mib-btn-md{height:36px;padding:0 18px;font-size:11.5px}
.mib-btn-lg{height:44px;padding:0 24px;font-size:13px}`;
export function ensureMibStyle(id,text){if(typeof document!=='undefined'&&!document.getElementById(id)){const s=document.createElement('style');s.id=id;s.textContent=text;document.head.appendChild(s);}}
export function Button({variant='primary',size='md',disabled=false,type='button',onClick,children,style}){
  ensureMibStyle('mib-btn-css',css);
  return <button type={type} disabled={disabled} onClick={onClick} className={`mib-btn mib-btn-${variant} mib-btn-${size}`} style={style}>{children}</button>;
}

import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-check{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-family:var(--font-body);font-size:14px;color:var(--text-body);user-select:none}
.mib-check input{position:absolute;opacity:0;width:0;height:0}
.mib-check .box{width:16px;height:16px;border:1px solid var(--border-strong);background:var(--surface-panel);display:inline-flex;align-items:center;justify-content:center;font-size:11px;line-height:1;color:transparent;transition:background-color var(--duration-fast) var(--ease-out-expo),color var(--duration-fast) var(--ease-out-expo);flex:none}
.mib-check input:checked+.box{background:var(--accent);border-color:var(--accent);color:var(--on-accent)}
.mib-check input:focus-visible+.box{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-check.disabled{opacity:0.4;cursor:not-allowed}`;
export function Checkbox({label,checked,defaultChecked,onChange,disabled=false,style}){
  ensureMibStyle('mib-check-css',css);
  return <label className={`mib-check${disabled?' disabled':''}`} style={style}>
    <input type="checkbox" checked={checked} defaultChecked={defaultChecked} disabled={disabled} onChange={e=>onChange&&onChange(e.target.checked)}/>
    <span className="box" aria-hidden="true">✓</span>
    {label}
  </label>;
}

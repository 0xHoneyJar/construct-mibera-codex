Flat text field with mono-caps label and hairline border; square, no shadow.

```jsx
<Input label="Wallet" placeholder="0x…" hint="Berachain mainnet" onChange={setAddr}/>
```

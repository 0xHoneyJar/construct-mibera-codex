import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-field{display:flex;flex-direction:column;gap:6px;font-family:var(--font-body)}
.mib-field-label{font-family:var(--font-mono);font-size:10px;letter-spacing:var(--tracking-caps);text-transform:uppercase;color:var(--text-secondary)}
.mib-input{height:36px;padding:0 12px;background:var(--surface-panel);color:var(--text-body);border:1px solid var(--border-default);border-radius:0;font-family:var(--font-body);font-size:14px;transition:border-color var(--duration-fast) var(--ease-out-expo)}
.mib-input::placeholder{color:var(--text-muted)}
.mib-input:hover:not(:disabled){border-color:var(--border-strong)}
.mib-input:focus{outline:2px solid var(--focus-ring);outline-offset:2px;border-color:var(--text-body)}
.mib-input:disabled{opacity:0.4;cursor:not-allowed}
.mib-input-error{border-color:var(--danger)}
.mib-field-hint{font-family:var(--font-mono);font-size:10px;letter-spacing:0.04em;color:var(--text-muted)}
.mib-field-hint.err{color:var(--danger)}`;
export function Input({label,placeholder,value,defaultValue,onChange,type='text',hint,error,disabled=false,style}){
  ensureMibStyle('mib-input-css',css);
  return <label className="mib-field" style={style}>
    {label && <span className="mib-field-label">{label}</span>}
    <input className={`mib-input${error?' mib-input-error':''}`} type={type} placeholder={placeholder} value={value} defaultValue={defaultValue} disabled={disabled} onChange={e=>onChange&&onChange(e.target.value)}/>
    {(error||hint) && <span className={`mib-field-hint${error?' err':''}`}>{error||hint}</span>}
  </label>;
}

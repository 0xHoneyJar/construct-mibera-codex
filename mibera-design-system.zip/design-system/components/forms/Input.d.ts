export interface InputProps {
  /** Mono-caps micro label above the field. */
  label?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  type?: string;
  /** Mono micro caption under the field. */
  hint?: string;
  /** Replaces hint, turns field rust. */
  error?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}

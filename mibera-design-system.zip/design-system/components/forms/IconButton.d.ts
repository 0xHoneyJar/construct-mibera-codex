export interface IconButtonProps {
  variant?: 'solid' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  /** Accessible name (also the tooltip). */
  label: string;
  disabled?: boolean;
  onClick?: () => void;
  /** A glyph — unicode character preferred (→ ✦ ✕ §), else a Lucide svg. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

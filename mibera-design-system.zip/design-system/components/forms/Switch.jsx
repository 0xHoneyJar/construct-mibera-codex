import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-switch{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-family:var(--font-body);font-size:14px;color:var(--text-body);user-select:none}
.mib-switch input{position:absolute;opacity:0;width:0;height:0}
.mib-switch .track{width:40px;height:20px;border:1px solid var(--border-strong);background:var(--surface-panel);position:relative;transition:background-color var(--duration-fast) var(--ease-out-expo),border-color var(--duration-fast) var(--ease-out-expo);flex:none}
.mib-switch .track::after{content:"";position:absolute;top:2px;left:2px;width:14px;height:14px;background:var(--text-muted);transition:transform var(--duration-fast) var(--spring-snappy),background-color var(--duration-fast) var(--ease-out-expo)}
.mib-switch input:checked+.track{background:var(--accent);border-color:var(--accent)}
.mib-switch input:checked+.track::after{transform:translateX(20px);background:var(--on-accent)}
.mib-switch input:focus-visible+.track{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-switch.disabled{opacity:0.4;cursor:not-allowed}`;
export function Switch({label,checked,defaultChecked,onChange,disabled=false,style}){
  ensureMibStyle('mib-switch-css',css);
  return <label className={`mib-switch${disabled?' disabled':''}`} style={style}>
    <input type="checkbox" role="switch" checked={checked} defaultChecked={defaultChecked} disabled={disabled} onChange={e=>onChange&&onChange(e.target.checked)}/>
    <span className="track" aria-hidden="true"></span>
    {label}
  </label>;
}

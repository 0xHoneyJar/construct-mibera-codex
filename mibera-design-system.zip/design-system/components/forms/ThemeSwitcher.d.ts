export interface ThemeSwitcherProps {
  /** Controlled theme id: nier-default | acid-house | freetekno | chicago-detroit-nyc | milady. */
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
  /** 'document' (default) sets data-theme on <html>; 'none' leaves application to you. */
  applyTo?: 'document' | 'none';
  style?: React.CSSProperties;
}

import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-select-wrap{position:relative;display:flex;flex-direction:column;gap:6px}
.mib-select{appearance:none;-webkit-appearance:none;height:36px;padding:0 32px 0 12px;background:var(--surface-panel);color:var(--text-body);border:1px solid var(--border-default);border-radius:0;font-family:var(--font-body);font-size:14px;cursor:pointer;transition:border-color var(--duration-fast) var(--ease-out-expo)}
.mib-select:hover:not(:disabled){border-color:var(--border-strong)}
.mib-select:focus{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-select:disabled{opacity:0.4;cursor:not-allowed}
.mib-select-chev{position:absolute;right:12px;bottom:11px;pointer-events:none;font-size:10px;color:var(--text-muted);font-family:var(--font-mono)}`;
export function Select({label,options=[],value,defaultValue,onChange,disabled=false,style}){
  ensureMibStyle('mib-select-css',css);
  return <label className="mib-select-wrap" style={style}>
    {label && <span className="mib-field-label" style={{fontFamily:'var(--font-mono)',fontSize:10,letterSpacing:'var(--tracking-caps)',textTransform:'uppercase',color:'var(--text-secondary)'}}>{label}</span>}
    <select className="mib-select" value={value} defaultValue={defaultValue} disabled={disabled} onChange={e=>onChange&&onChange(e.target.value)}>
      {options.map(o=>typeof o==='string'?<option key={o} value={o}>{o}</option>:<option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
    <span className="mib-select-chev">▼</span>
  </label>;
}

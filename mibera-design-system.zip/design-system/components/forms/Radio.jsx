import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-radio{display:inline-flex;align-items:center;gap:10px;cursor:pointer;font-family:var(--font-body);font-size:14px;color:var(--text-body);user-select:none}
.mib-radio input{position:absolute;opacity:0;width:0;height:0}
.mib-radio .dot{width:16px;height:16px;border-radius:50%;border:1px solid var(--border-strong);background:var(--surface-panel);transition:box-shadow var(--duration-fast) var(--ease-out-expo),border-color var(--duration-fast) var(--ease-out-expo);flex:none}
.mib-radio input:checked+.dot{border-color:var(--accent);box-shadow:inset 0 0 0 4px var(--surface-panel),inset 0 0 0 16px var(--accent)}
.mib-radio input:focus-visible+.dot{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-radio.disabled{opacity:0.4;cursor:not-allowed}`;
export function Radio({label,name,value,checked,defaultChecked,onChange,disabled=false,style}){
  ensureMibStyle('mib-radio-css',css);
  return <label className={`mib-radio${disabled?' disabled':''}`} style={style}>
    <input type="radio" name={name} value={value} checked={checked} defaultChecked={defaultChecked} disabled={disabled} onChange={e=>onChange&&onChange(value)}/>
    <span className="dot" aria-hidden="true"></span>
    {label}
  </label>;
}

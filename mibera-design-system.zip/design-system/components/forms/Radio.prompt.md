Radio with accent-ring checked state; the circle is the one licensed round element besides pills.

```jsx
<Radio name="time" value="kaironic" label="Kaironic time" defaultChecked/>
```

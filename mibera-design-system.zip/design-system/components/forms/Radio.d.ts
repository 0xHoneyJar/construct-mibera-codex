export interface RadioProps {
  label?: React.ReactNode;
  /** Group name — radios sharing a name are exclusive. */
  name: string;
  value: string;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (value: string) => void;
  disabled?: boolean;
  style?: React.CSSProperties;
}

export interface SelectProps {
  label?: string;
  /** Strings or {value,label} pairs. */
  options: Array<string | { value: string; label: string }>;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  disabled?: boolean;
  style?: React.CSSProperties;
}

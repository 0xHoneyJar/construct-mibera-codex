Square icon-only button; pass a unicode glyph as the child (house style prefers glyphs over icon fonts).

```jsx
<IconButton label="Close" variant="ghost">✕</IconButton>
```

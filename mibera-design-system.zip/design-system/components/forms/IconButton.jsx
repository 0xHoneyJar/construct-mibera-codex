import {ensureMibStyle} from './Button.jsx';
const css=`
.mib-iconbtn{display:inline-flex;align-items:center;justify-content:center;font-family:var(--font-mono);border-radius:0;cursor:pointer;transition:background-color var(--duration-fast) var(--ease-out-expo),color var(--duration-fast) var(--ease-out-expo),border-color var(--duration-fast) var(--ease-out-expo)}
.mib-iconbtn:active:not(:disabled){transform:translateY(1px)}
.mib-iconbtn:focus-visible{outline:2px solid var(--focus-ring);outline-offset:2px}
.mib-iconbtn:disabled{opacity:0.4;cursor:not-allowed}
.mib-iconbtn-solid{background:var(--accent);color:var(--on-accent);border:1px solid var(--accent)}
.mib-iconbtn-solid:hover:not(:disabled){background:color-mix(in oklch,var(--accent) 82%,var(--surface-page))}
.mib-iconbtn-outline{background:transparent;color:var(--text-body);border:1px solid var(--border-default)}
.mib-iconbtn-outline:hover:not(:disabled){border-color:var(--text-body);background:var(--surface-panel)}
.mib-iconbtn-ghost{background:transparent;color:var(--text-secondary);border:1px solid transparent}
.mib-iconbtn-ghost:hover:not(:disabled){color:var(--text-body);background:var(--surface-panel)}
.mib-iconbtn-sm{width:28px;height:28px;font-size:13px}
.mib-iconbtn-md{width:36px;height:36px;font-size:15px}
.mib-iconbtn-lg{width:44px;height:44px;font-size:18px}`;
export function IconButton({variant='outline',size='md',label,disabled=false,onClick,children,style}){
  ensureMibStyle('mib-iconbtn-css',css);
  return <button type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick} className={`mib-iconbtn mib-iconbtn-${variant} mib-iconbtn-${size}`} style={style}>{children}</button>;
}

Square-thumbed toggle; on-state fills the track with the register accent.

```jsx
<Switch label="Ravepill mode" defaultChecked onChange={setRave}/>
```

16px square checkbox; checked fills with the register accent.

```jsx
<Checkbox label="I am ungovernable" defaultChecked onChange={setOk}/>
```

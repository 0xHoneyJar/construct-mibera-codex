Segmented control switching between the five canonical Mibera themes (verbatim from mibera-dimensions `lib/themes.ts`); by default it sets `data-theme` on `<html>` so every semantic token re-resolves.

```jsx
<ThemeSwitcher defaultValue="acid-house" onChange={setTheme}/>
```

Also exports `MIBERA_THEMES` (id/name/swatch data) for building custom pickers.

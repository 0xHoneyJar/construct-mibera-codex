Native select styled to the flat-field register, ▼ glyph chevron.

```jsx
<Select label="Archetype" options={['Freetekno','Milady','Chicago Detroit','Acidhouse']} onChange={setTribe}/>
```

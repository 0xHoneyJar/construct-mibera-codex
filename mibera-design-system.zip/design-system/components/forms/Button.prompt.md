Flat square button in mono caps — the house action element; use for any clickable action in either register.

```jsx
<Button variant="primary" size="md" onClick={mint}>Mint Mibera</Button>
```

Variants: `primary` (accent fill — ink on Codex, tribe color in rave themes), `secondary` (hairline), `ghost`, `danger`. Never round corners; label auto-uppercases.

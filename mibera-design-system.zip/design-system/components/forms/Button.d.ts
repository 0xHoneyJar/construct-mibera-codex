export interface ButtonProps {
  /** Visual weight. primary = accent fill, secondary = hairline outline, ghost = text-only, danger = rust. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** sm 28px · md 36px · lg 44px */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  type?: 'button' | 'submit';
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

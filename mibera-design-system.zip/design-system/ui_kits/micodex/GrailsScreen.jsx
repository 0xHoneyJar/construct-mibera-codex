const GCDN="https://assets.0xhoneyjar.xyz/Mibera/grails/";
const GRAILS=[
 {slug:"sun",name:"Sun",cat:"Celestial"},{slug:"moon",name:"Moon",cat:"Celestial"},{slug:"mercury",name:"Mercury",cat:"Planetary"},{slug:"venus",name:"Venus",cat:"Planetary"},
 {slug:"mars",name:"Mars",cat:"Planetary"},{slug:"jupiter",name:"Jupiter",cat:"Planetary"},{slug:"saturn",name:"Saturn",cat:"Planetary"},{slug:"black-hole",name:"Black Hole",cat:"Celestial"},
 {slug:"fire",name:"Fire",cat:"Elemental"},{slug:"water",name:"Water",cat:"Elemental"},{slug:"air",name:"Air",cat:"Elemental"},{slug:"earth",name:"Earth",cat:"Elemental"},
 {slug:"aries",name:"Aries",cat:"Zodiac"},{slug:"gemini",name:"Gemini",cat:"Zodiac"},{slug:"leo",name:"Leo",cat:"Zodiac"},{slug:"scorpio",name:"Scorpio",cat:"Zodiac"},
 {slug:"greek",name:"Greek",cat:"Ancestor"},{slug:"hindu",name:"Hindu",cat:"Ancestor"},{slug:"mayan",name:"Mayan",cat:"Ancestor"},{slug:"japanese",name:"Japanese",cat:"Ancestor"},
 {slug:"satoshi-as-hermes",name:"Satoshi as Hermes",cat:"Community"},{slug:"gaia",name:"Gaia",cat:"Mythic"},{slug:"past",name:"Past",cat:"Temporal"},{slug:"future",name:"Future",cat:"Temporal"}
];
const CATS=["All","Celestial","Planetary","Elemental","Zodiac","Ancestor","Temporal","Mythic","Community"];
function GrailsScreen(){
 const {Tabs}=window.MiberaGeneralDesignSystem_6d73c4||{};
 const [cat,setCat]=React.useState("All");
 const list=GRAILS.filter(g=>cat==="All"||g.cat===cat);
 return <div className="mx-content wide">
  <p className="mx-kicker">V. THE COLLECTION · LOOKUP_GRAIL</p>
  <h1 className="mx-h1">The Grails</h1>
  <p className="mx-lead">44 hand-drawn 1/1 art pieces — 42 canonical + 2 community. Hand-painted on iPad in Procreate over 18 months. Showing {list.length} of 44.</p>
  {Tabs&&<div style={{marginTop:'1.25rem'}}><Tabs items={CATS} value={cat} onChange={setCat}/></div>}
  <div className="mx-grails">
   {list.map(g=><div key={g.slug} className="mx-grail">
    <img src={GCDN+g.slug+".webp"} alt={g.name} loading="lazy"/>
    <div className="mx-grail-body"><span className="mx-grail-name">{g.name}</span><span className="mx-grail-cat">{g.cat}</span></div>
   </div>)}
  </div>
 </div>;
}
Object.assign(window,{GrailsScreen});

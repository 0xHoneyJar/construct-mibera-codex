const NAV=[
 {sec:"Front Matter",items:[{id:"home",label:"What Is the Codex?"},{id:"agents",label:"For Agents"}]},
 {sec:"I. The Story",items:[{id:"philosophy",label:"Philosophy & Genesis"},{id:"lore",label:"The Lore Articles"}]},
 {sec:"II. The Framework",items:[{id:"tribes",label:"The Four Tribes"},{id:"ancestors",label:"Ancestors"}]},
 {sec:"V. The Collection",items:[{id:"miberas",label:"The 10,000"},{id:"grails",label:"The Grails"}]},
 {sec:"IX. On-Chain",items:[{id:"onchain",label:"Contracts & Mechanics"}]},
 {sec:"X. Data & Research",items:[{id:"data",label:"Data & Research"}]}
];
function Sidebar({view,onNav}){
 return <aside className="mx-sidebar">
  <div className="mx-brand"><img src="../../assets/favicon.png" alt=""/>Mibera Codex</div>
  <button className="mx-search" onClick={()=>alert('Search the codex — 11,476 nodes, 191,882 edges.')}><span>Search…</span><kbd>⌘K</kbd></button>
  {NAV.map(g=><div key={g.sec}><div className="mx-section">{g.sec}</div><nav className="mx-nav">
   {g.items.map(it=><button key={it.id} className={view===it.id?'active':''} onClick={()=>onNav(it.id)}>{it.label}</button>)}
  </nav></div>)}
 </aside>;
}
Object.assign(window,{Sidebar});

const CDN="https://assets.0xhoneyjar.xyz/Mibera/grails/";
function HomeScreen({onNav}){
 return <div className="mx-content">
  <div className="mx-hero">
   <div className="mx-hero-copy">
    <h1 className="mx-hero-title">The Mibera Codex</h1>
    <p className="mx-hero-lede">"Milady has to die, so that Milady may live. Milady lost her way. And in ego death, she finds Mibera."</p>
    <p className="mx-hero-body">Documentation for Mibera Maker — 10,000 time-travelling Rebased Retard Beras carrying the eternal flame of the Rave. Read by agents, browsed by humans, tools shared between.</p>
   </div>
   <div className="mx-try">
    <span className="mx-try-label">Try the grimoire MCP</span>
    <pre className="mx-try-snippet">{`lookup_archetype("freetekno")
→ { era: "Early-Late 90s",
    season: "Summer",
    zodiac: ["Cancer","Leo","Virgo"] }`}</pre>
    <span className="mx-try-more" onClick={()=>onNav('tribes')}>see all eight tools →</span>
   </div>
  </div>
  <ol className="mx-steps">
   <li className="mx-step"><i>I.</i><div><b>The codex is the source of truth.</b><p>Canonical lore for zones, archetypes, factors, grails and all 10,000 Miberas — anti-hallucination infrastructure for narrative bots.</p></div></li>
   <li className="mx-step"><i>II.</i><div><b>Agents read, never invent.</b><p>Eight lookup tools return the HARD canonical set; creative license lives only in the SOFT layer.</p></div></li>
   <li className="mx-step"><i>III.</i><div><b>Humans browse the grimoires.</b><p>The same material, shelved as books — parchment and ink, the way a codex should read.</p></div></li>
  </ol>
  <div className="mx-shelf" onClick={()=>onNav('grails')}>
   <img className="mx-shelf-cover" src={CDN+"sun.webp"} alt="Vol I cover" loading="lazy"/>
   <div><div className="mx-shelf-title">Mibera Maker · Vol I — The Grails</div><div className="mx-shelf-hint">44 hand-drawn 1/1 art pieces: 42 canonical + 2 community. Zodiacs, elements, planets, ancestors.</div><div className="mx-shelf-meta">lookup_grail · 44 entries</div></div>
  </div>
  <div className="mx-shelf" onClick={()=>onNav('tribes')}>
   <img className="mx-shelf-cover" src={CDN+"moon.webp"} alt="Vol II cover" loading="lazy"/>
   <div><div className="mx-shelf-title">Vol II — The Four Tribes</div><div className="mx-shelf-hint">Freetekno, Milady, Chicago Detroit, Acidhouse — the rave movements that define every Mibera's value system.</div><div className="mx-shelf-meta">lookup_archetype · 4 entries</div></div>
  </div>
  <div className="mx-shelf" onClick={()=>onNav('miberas')}>
   <img className="mx-shelf-cover" src={CDN+"future.webp"} alt="Vol III cover" loading="lazy"/>
   <div><div className="mx-shelf-title">Vol III — The 10,000</div><div className="mx-shelf-hint">Every Mibera with full canonical trait set: archetype, ancestor, birthday, molecule, tarot, swag rank.</div><div className="mx-shelf-meta">lookup_mibera · 10,000 entries</div></div>
  </div>
 </div>;
}
Object.assign(window,{HomeScreen});

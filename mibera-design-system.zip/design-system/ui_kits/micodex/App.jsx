function StubScreen({title,kicker,note}){
 return <div className="mx-content">
  <p className="mx-kicker">{kicker}</p>
  <h1 className="mx-h1">{title}</h1>
  <p className="mx-lead">{note}</p>
  <div style={{marginTop:'1.5rem',padding:'1.05rem 1.4rem',border:'1px solid var(--rule-soft)',background:'var(--parchment-panel)',fontSize:'0.85rem',color:'var(--ink-3)',fontStyle:'italic'}}>Screen intentionally not recreated — not part of this kit's three core views.</div>
 </div>;
}
function App(){
 const [view,setView]=React.useState('home');
 const main=React.useRef(null);
 const nav=v=>{setView(v);if(main.current)main.current.scrollTop=0;};
 const STUBS={
  agents:["FRONT MATTER","For Agents","One URL to paste: the skill.md endpoint that turns any agent into a codex reader."],
  philosophy:["I. THE STORY","Philosophy & Genesis","The foundational mythology: the Milady identity crisis, the awakening, Chronos and Kairos."],
  lore:["I. THE STORY","The Lore Articles","The 7-part series exploring the Trinity of HONEY, BERA, and BGT."],
  ancestors:["II. THE FRAMEWORK","Ancestors","33 cultural lineages carried across eras by the time-travelling beras."],
  miberas:["V. THE COLLECTION","The 10,000","Every Mibera with archetype, ancestor, birthday, molecule, tarot, swag rank."],
  onchain:["IX. ON-CHAIN","Contracts & Mechanics","11 ecosystem contracts. No governance, no admin keys — pure autonomous code."],
  data:["X. DATA & RESEARCH","Data & Research","Knowledge graph: 11,476 nodes, 191,882 edges. JSONL exports of all entries."]
 };
 return <div className="mx-app">
  <Sidebar view={view} onNav={nav}/>
  <main className="mx-main" ref={main}>
   {view==='home'&&<HomeScreen onNav={nav}/>}
   {view==='tribes'&&<TribesScreen/>}
   {view==='grails'&&<GrailsScreen/>}
   {STUBS[view]&&<StubScreen kicker={STUBS[view][0]} title={STUBS[view][1]} note={STUBS[view][2]}/>}
  </main>
 </div>;
}
/* Render only in the UI-kit page context: index.html sets __MICODEX_PAGE__ before loading this via babel. (This file is also swept into _ds_bundle.js, where the flag is absent and rendering must not run.) */
if(window.__MICODEX_PAGE__&&document.getElementById('root')){
 ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
}

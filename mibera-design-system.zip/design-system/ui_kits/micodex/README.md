# MiCodex UI Kit

Recreation of the MiCodex docs site (codex.0xhoneyjar.xyz) — the only shipped Mibera product UI. Values are lifted verbatim from `reference/micodex-global.css` (the site's real stylesheet): codex-hero, grimoire-shelf, archetype-card, sidebar chrome.

Screens (switch via sidebar):
- **Home** — "What Is the Codex?": hero + ink try-panel, numbered steps, grimoire shelves
- **The Four Tribes** — archetype browse grid (lookup_archetype tool page)
- **The Grails** — cathedral grid with real grail art hot-linked from `assets.0xhoneyjar.xyz`

`micodex.css` holds the register-specific CSS; tokens come from the root `styles.css`. Grail imagery requires network access; cards degrade to framed panels offline.

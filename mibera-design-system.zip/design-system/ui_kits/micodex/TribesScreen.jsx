const TRIBES=[
 {name:"Freetekno",era:"Early–Late 90s",season:"Summer",zodiac:"Cancer · Leo · Virgo",figures:"Spiral Tribe, MF Doom, DiY Collective (Digs & Woosh), DJ PGZ, Frank Waln",modern:"LSD, DMT, Speed",ancient:"Khat, Ayahuasca",fashion:"Steampunk glasses, black graphic tees, military cargo jacket, camo hat, pilot cap, fluoro accessories, silver mask"},
 {name:"Milady",era:"Current",season:"Winter",zodiac:"Capricorn · Aquarius · Pisces",figures:"Grimes, Remilia, Charlotte Fang, Network Spirituality",modern:"LSD, DMT, Ketamine",ancient:"Khat, Ayahuasca",fashion:'Business suits, black t-shirts with Milady text, "Mottega" glasses, camo hat'},
 {name:"Chicago Detroit",era:"Early 80s",season:"Spring",zodiac:"Aries · Taurus · Gemini",figures:"Ron Hardy, The Chosen Few DJs, Lee \u201CScratch\u201D Perry, Sun Ra, Marsha P. Johnson",modern:"NOS, Poppers, Cocaine, MDMA",ancient:"Cannabis, Khat, Tobacco",fashion:"Tight leather jackets, white headband, 80s tracksuit, pearl jewelry, Chicago Bulls top, Rayban glasses"},
 {name:"Acidhouse",era:"Late 90s / 2000s",season:"Fall",zodiac:"Libra · Scorpio · Sagittarius",figures:"The Grateful Dead, DJ Bus Replacement Service, New Travellers",modern:"MDMA, Ecstasy, LSD, Ketamine, GHB, 2C-B",ancient:"Cannabis, Psilocybin Mushrooms, Morning Glory Seeds",fashion:"Black bomber jacket with badges, white smiley face tees, swimming goggles, gold hoop"}
];
function TribesScreen(){
 return <div className="mx-content wide">
  <p className="mx-kicker">II. THE FRAMEWORK · LOOKUP_ARCHETYPE</p>
  <h1 className="mx-h1">The Four Tribes</h1>
  <p className="mx-lead">Each archetype represents a distinct rave movement, era, and aesthetic. Miberas are assigned to an archetype based on their astrological birth data.</p>
  <div className="mx-tribes">
   {TRIBES.map(t=><div key={t.name} className="mx-tribe">
    <div className="mx-tribe-head"><h2 className="mx-tribe-name">{t.name}</h2>
     <div className="mx-tribe-meta"><span>{t.era}</span><span className="sep">·</span><span>{t.season}</span><span className="sep">·</span><span>{t.zodiac}</span></div></div>
    <div className="mx-tribe-sec"><span className="mx-tribe-label">Key figures</span><p className="mx-tribe-body">{t.figures}</p></div>
    <div className="mx-tribe-sec split">
     <div className="mx-tribe-sec"><span className="mx-tribe-label">Modern</span><p className="mx-tribe-body">{t.modern}</p></div>
     <div className="mx-tribe-sec"><span className="mx-tribe-label">Ancient</span><p className="mx-tribe-body">{t.ancient}</p></div>
    </div>
    <div className="mx-tribe-sec"><span className="mx-tribe-label">Fashion</span><p className="mx-tribe-body fashion">{t.fashion}</p></div>
   </div>)}
  </div>
 </div>;
}
Object.assign(window,{TribesScreen});

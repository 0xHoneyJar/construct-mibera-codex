# Mibera General Design System

**Mibera** — 10,000 time-travelling "Rebased Retard Beras" carrying the eternal flame of the Rave. Mibera is the shadow side of Milady: where Milady is the **clearpill** (virtuous, supplements, suits), Mibera is the **ravepill** (the sweaty, filthy reality of the dance floor). An NFT collection + lore universe + on-chain ecosystem by 0xHoneyJar on Berachain. Motto register: *"MIBERA IS A FULLY AUTONOMOUS UNGOVERNABLE TREASURY RAVE. MIBERA REFUSES MILADY."*

## Sources
- **GitHub:** [0xHoneyJar/construct-mibera-codex](https://github.com/0xHoneyJar/construct-mibera-codex) — the Mibera Codex: canonical lore, the four archetypes, festival-zone vocabulary, the MiCodex docs site (`docs/`, a vocs app whose `docs/public/global.css` is the only real shipped UI — copied verbatim to `reference/micodex-global.css`). Explore it further to ground new designs; `core-lore/` and `IDENTITY.md` are the voice bible.
- **GitHub:** [0xHoneyJar/mibera-dimensions](https://github.com/0xHoneyJar/mibera-dimensions) — MiDi, the Next.js app. Source of truth for the THEME SYSTEM: `lib/themes.ts` (theme registry) and `styles/globals.css` (`--theme-*` scopes, copied verbatim into `tokens/colors.css`). Also `lib/design-system.ts` (app-side token map).
- **Brand boards (uploads/):** `acidhouse.png`, `freetekno brand.png`, `chicago detroit brand.png`, `milady brand.png` — one board per Rave Tribe defining that tribe's palette + type pairing.
- Live docs: https://codex.0xhoneyjar.xyz · Grail art CDN: `https://assets.0xhoneyjar.xyz/Mibera/grails/<slug>.webp`

## The theme system (five switchable themes)
Values verbatim from mibera-dimensions. Set `data-theme` on `<html>` or any subtree; every semantic token (`--surface-page`, `--text-body`, `--accent`, …) re-resolves. No theme is privileged — switching is the point (use the `ThemeSwitcher` component).
- `nier-default` — parchment + ink. The grimoire register; `:root` default.
- `acid-house` — magenta `oklch(0.606 0.181 345.2)` on near-black plum.
- `freetekno` — green `oklch(0.659 0.124 156.5)` on dark forest.
- `chicago-detroit-nyc` — rust `oklch(0.567 0.153 29.1)` + navy text on pale blue-grey.
- `milady` — purple `oklch(0.582 0.149 313.7)` on soft pink-grey.
Themes change COLOR ONLY — the app keeps one global face across themes. Raw theme vars: `--theme-primary` (text), `--theme-secondary` (support accent), `--theme-accent` (brand accent), `--theme-tertiary` (page bg), `--theme-accent-rgb`.

**Dynamic theme switching caveat:** when applying `data-theme` at runtime, suppress transitions for one frame (inject `*{transition:none!important}`, set the attribute, force reflow, remove next frame — the next-themes `disableTransitionOnChange` pattern). Chromium otherwise pins stale transitioned colors when `var()` endpoints change via inherited custom properties. `ThemeSwitcher` does this for you.

**Board palettes** (uploads/*.png — poster/merch art direction, raw tokens only, NOT the app themes):
- Acidhouse board: `#FFEF00` / `#FF2ED8` / `#00FFE5`; Rubik Mono One + Geist
- Freetekno board: `#00FF66` on black; Oswald + IBM Plex Mono
- Chicago Detroit board: `#E6C85C` / `#C04B3E` / `#1A2D5C`; EB Garamond + Archivo Narrow
- Milady board: `#FF70C7` / `#8BD3FF` / `#B97AFF` / soft grey `#FFF6FB`; Kanit + Archivo Narrow

## CONTENT FUNDAMENTALS
- **Voice**: first-person plural mythic — "We are time-travelling Rebased Retard Beras." Declarative, incantatory, comma-spliced momentum. Aphorisms in triads: "Become Ungovernable. The Old Collapses. Mibera Refuses."
- **Registers mix high and low**: Plato, Jung, Hakim Bey and CCRU sit next to "retard", "k-hole", "gm". Academic etymology drops ("The term 'taboo' comes from the Polynesian 'tapu'…") beside shitpost slang. Never corporate, never apologetic, never exclamation-mark cheerful.
- **Casing**: sentence case for prose; Title Case for lore proper nouns (the Rave, the High Council of 101 Bears, Kaironic time); ALL-CAPS for manifesto lines and labels ("THE GRIMOIRE MCP"). Product names mixed-case with Mi- prefix: MiCodex, MiParcels, MiReveal.
- **Terminology**: archetype/tribe, ancestor, grail, fracture, swag score (SS1–SS5, SSS–F ranks), clearpill/ravepill, TAZ, Chronic vs Kaironic time. Use them exactly; the codex is anti-hallucination infrastructure.
- **Emoji**: essentially none in brand surfaces (docs use a rare 📡 as a broadcast glyph). Do not decorate with emoji.
- **Numbers as lore**: 10,000 Miberas, 101 Bears, 1,337+ traits, 44 grails, 78 drug-tarot cards, the 42 motif. Quote them precisely.
- Example copy, verbatim: *"Milady has to die, so that Milady may live. Milady lost her way. And in ego death, she finds Mibera."*

## VISUAL FOUNDATIONS
- **Color**: five app themes (see above) — each pairs `--theme-tertiary` page with `--theme-primary` text and ONE saturated `--theme-accent` used as signal, not wash. Board palettes are for poster/merch moments. Never mix two themes in one composition (except deliberate "all tribes" moments).
- **Type**: Codex = Imperial BT (serif display, letterspaced caps for h1), Switzer (body, `ss01/ss02/cv01/cv11` features), Clash Display (brand marks). Tribes = their board pairings (see registers above). House label style: wide-tracked mono uppercase kickers (`letter-spacing:0.22em`).
- **Corners**: SQUARE. `border-radius:0` everywhere (scrollbars included). Pills only for Badge/Tag capsule variant (`--radius-full`).
- **Borders & rules**: hairlines of the text color at 6/10/20% opacity (`--rule-subtle/soft/medium`). Emphasis = 2px solid text-color, or inverse panel. No colored 1px gray borders.
- **Shadows**: none. Depth = surface steps (page → panel → panel-2) and hairlines. `--shadow-lift` is a 1px ring, not a blur.
- **Backgrounds**: flat fields. Codex may use panel-tone plates; Rave uses black with accent typography. Imagery (grail art, trait art) sits in hairline-framed plates, never behind text without a solid panel.
- **Motion**: expo easings + springs (`--ease-out-expo`, `--spring-snappy`), 100–600ms tokens. Fades and small translates; no parallax, no bounce-for-fun outside `--spring-bouncy` accents.
- **Hover**: text → underline-color to full; buttons/panels → surface step darker (Codex) or accent fill/inverse swap (Rave). Press: translateY(1px), no scale tricks.
- **Focus**: 2px solid `--focus-ring` outline, offset 2px. Visible, square.
- **Imagery**: hand-painted (Procreate) character art; warm candle-lit palette in codex art (grimoire spines, gold numerals); tribe photography would be grainy, flash-lit, documentary. No gradients as decoration; the only gradient license is UV/neon glow inside Rave registers.
- **Layout**: generous margins, centered measure ~68ch for prose; label-rule-content rhythm (kicker, hairline, body). Fixed headers are ink-on-parchment inversions.
- **Transparency/blur**: none. Solid panels only.

## ICONOGRAPHY
- No proprietary icon font or SVG set exists in the codex repo (its `docs/public/agents|logos` SVGs are third-party vendor marks, not brand icons — not copied).
- House practice: **typographic glyphs and unicode** as icons — Roman numerals (I–VII grimoire spines), ✦/§/→ style marks, wide-tracked labels instead of icons. Prefer a glyph or a word over an icon.
- When a real icon is unavoidable, use **Lucide via CDN** at `stroke-width:1.5` (closest to the hairline register) and flag it as a substitution. Do not hand-draw SVGs, do not use emoji.
- Logos in `assets/`: `logo.png` (MICODEX Imperial wordmark on ink, 1:1), `favicon.png`, `og.png` (social card), `codex-avatar.jpg`, `miberasets-row.jpg` (Honey Road sets strip). There is **no standalone Mibera bear mark** in the sources — render the word "MIBERA" in the register's display face where a mark would go.

## Index
- `styles.css` → imports `tokens/` (fonts, colors, typography, spacing, motion, base)
- `assets/` — logo, favicon, og card, avatar, sets strip, 3 font binaries
- `reference/micodex-global.css` — verbatim shipped CSS of the MiCodex docs site (ground truth)
- `guidelines/` — specimen cards (colors, type, spacing, motion, brand)
- `components/forms/` — ThemeSwitcher, Button, IconButton, Input, Select, Checkbox, Radio, Switch
- `components/surfaces/` — Card, Badge, Tag, Tabs, Dialog, Toast, Tooltip
  (standard set: no component library exists in the sources; see "Intentional additions")
- `ui_kits/micodex/` — recreation of the MiCodex docs site (home + tool page), from `reference/micodex-global.css`
- `SKILL.md` — agent skill entrypoint

## Intentional additions
- The `components/` set is authored from the visual foundations (the codex repo has no reusable UI kit; mibera-dimensions components are app-specific). `ThemeSwitcher` is grounded in mibera-dimensions `lib/themes.ts` (the app's own theme selector registry).
- Archetype board faces are loaded from **Google Fonts CDN** (Rubik Mono One, Geist, Oswald, IBM Plex Mono, EB Garamond, Archivo Narrow, Kanit) — the boards shipped as PNGs without binaries. Imperial BT / Switzer / Clash Display are the real files.

---
name: mibera-design
description: Use this skill to generate well-branded interfaces and assets for Mibera, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

Key facts: Mibera has five switchable themes (verbatim from mibera-dimensions): `nier-default` (parchment + ink, `:root` default), `acid-house`, `freetekno`, `chicago-detroit-nyc`, `milady` — set `data-theme` on `<html>` or any subtree, or use the `ThemeSwitcher` component. Themes change color only; type stays Imperial BT/Switzer. Link `styles.css` for all tokens; corners are square, depth is hairlines not shadows, labels are wide-tracked mono caps. Voice is mythic first-person-plural, no emoji.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
